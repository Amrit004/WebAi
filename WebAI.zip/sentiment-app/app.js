document.addEventListener('DOMContentLoaded', () => {
    const analyzeBtn = document.getElementById('analyzeBtn');
    const inputText = document.getElementById('inputText');
    const resultDiv = document.getElementById('result');
    const loadingIndicator = document.getElementById('loading');

    analyzeBtn.addEventListener('click', async () => {
        const text = inputText.value.trim();
        
        if (!text) {
            alert('Please enter some text to analyze.');
            return;
        }

        try {
            // Show loading state
            loadingIndicator.style.display = 'block';
            resultDiv.textContent = '';
            
            const response = await fetch('http://localhost:3000/analyze-sentiment', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ text })
            });

            if (!response.ok) {
                const errorData = await response.json();
                throw new Error(errorData.error || 'Analysis failed');
            }

            const data = await response.json();
            
            // Display results
            resultDiv.innerHTML = `
                <p><strong>Sentiment:</strong> <span class="${data.sentiment}">${data.sentiment}</span></p>
                <p><strong>Confidence:</strong> ${Math.round(data.confidence * 100)}%</p>
            `;

        } catch (error) {
            console.error('Error:', error);
            resultDiv.textContent = `Error: ${error.message}`;
        } finally {
            loadingIndicator.style.display = 'none';
        }
    });
});