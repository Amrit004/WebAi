require('dotenv').config();
const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Sentiment Analysis Endpoint
app.post('/analyze-sentiment', async (req, res) => {
    try {
        const { text } = req.body;
        
        if (!text) {
            return res.status(400).json({ error: 'Text is required' });
        }

        const response = await axios.post(
            'https://api.openai.com/v1/chat/completions',
            {
                model: "gpt-3.5-turbo",
                messages: [{
                    role: "user",
                    content: `Analyze the sentiment of this text: "${text}". 
                             Respond ONLY with JSON format: {
                                "sentiment": "positive/neutral/negative", 
                                "confidence": 0-1
                             }`
                }],
                temperature: 0.7
            },
            {
                headers: {
                    'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
                    'Content-Type': 'application/json'
                }
            }
        );

        // Parse the GPT response
        const content = response.data.choices[0].message.content;
        const result = JSON.parse(content);
        
        res.json({
            sentiment: result.sentiment,
            confidence: result.confidence
        });

    } catch (error) {
        console.error('API Error:', error.response?.data || error.message);
        res.status(500).json({
            error: 'Sentiment analysis failed',
            details: error.response?.data || error.message
        });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});